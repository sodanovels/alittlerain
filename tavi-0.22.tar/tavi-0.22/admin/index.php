<?php
// $Id: index.php,v 1.7 2002/01/07 18:13:58 smoonen Exp $

chdir('..');
require('action/admin.php');
?>
