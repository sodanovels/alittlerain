<?php
// $Id: index.php,v 1.11 2002/01/07 18:13:58 smoonen Exp $
require('lib/main.php');
?>
